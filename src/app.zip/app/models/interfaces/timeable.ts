export interface Timeable  {
 time:number
  }
  