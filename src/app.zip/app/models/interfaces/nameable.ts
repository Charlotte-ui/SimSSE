
export interface Nameable {
    getName: () => string;
}